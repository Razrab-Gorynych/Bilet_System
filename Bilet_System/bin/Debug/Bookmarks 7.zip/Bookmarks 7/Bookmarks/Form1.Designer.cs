﻿namespace Bookmarks
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series5 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title3 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend4 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series6 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title4 = new System.Windows.Forms.DataVisualization.Charting.Title();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.read = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.voyti = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lessons = new System.Windows.Forms.NumericUpDown();
            this.stud = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.rand = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.studb = new System.Windows.Forms.Label();
            this.Studg = new System.Windows.Forms.Label();
            this.studgr = new System.Windows.Forms.Label();
            this.studbr = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.lesb = new System.Windows.Forms.Label();
            this.lesg = new System.Windows.Forms.Label();
            this.lesgr = new System.Windows.Forms.Label();
            this.lesbr = new System.Windows.Forms.Label();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.list_les = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.listst = new System.Windows.Forms.ListBox();
            this.label7 = new System.Windows.Forms.Label();
            this.comboles = new System.Windows.Forms.ComboBox();
            this.list_st = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.listles = new System.Windows.Forms.ListBox();
            this.label6 = new System.Windows.Forms.Label();
            this.combost = new System.Windows.Forms.ComboBox();
            this.list = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.exit = new System.Windows.Forms.ListBox();
            this.stipplus = new System.Windows.Forms.ListBox();
            this.stip = new System.Windows.Forms.ListBox();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.button4 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.lesr = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chartkolvo = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lessons)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stud)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.list_les.SuspendLayout();
            this.list_st.SuspendLayout();
            this.list.SuspendLayout();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lesr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartkolvo)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(776, 426);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.Deselecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabControl1_Deselecting);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.read);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.lessons);
            this.tabPage1.Controls.Add(this.stud);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Controls.Add(this.rand);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(768, 400);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // read
            // 
            this.read.Location = new System.Drawing.Point(547, 354);
            this.read.Name = "read";
            this.read.Size = new System.Drawing.Size(174, 40);
            this.read.TabIndex = 8;
            this.read.Text = "Читать из файла";
            this.read.UseVisualStyleBackColor = true;
            this.read.Click += new System.EventHandler(this.read_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button3);
            this.groupBox1.Controls.Add(this.voyti);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Location = new System.Drawing.Point(281, 165);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 75);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Введите пароль";
            this.groupBox1.Visible = false;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(119, 42);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 8;
            this.button3.Text = "Отмена";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // voyti
            // 
            this.voyti.Location = new System.Drawing.Point(119, 15);
            this.voyti.Name = "voyti";
            this.voyti.Size = new System.Drawing.Size(75, 23);
            this.voyti.TabIndex = 7;
            this.voyti.Text = "Войти";
            this.voyti.UseVisualStyleBackColor = true;
            this.voyti.Click += new System.EventHandler(this.voyti_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(6, 19);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(99, 23);
            this.textBox1.TabIndex = 6;
            // 
            // lessons
            // 
            this.lessons.Location = new System.Drawing.Point(543, 23);
            this.lessons.Name = "lessons";
            this.lessons.Size = new System.Drawing.Size(46, 20);
            this.lessons.TabIndex = 5;
            this.lessons.ValueChanged += new System.EventHandler(this.lessons_ValueChanged);
            // 
            // stud
            // 
            this.stud.Location = new System.Drawing.Point(229, 23);
            this.stud.Name = "stud";
            this.stud.Size = new System.Drawing.Size(46, 20);
            this.stud.TabIndex = 4;
            this.stud.ValueChanged += new System.EventHandler(this.stud_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(348, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(189, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "Количество предметов";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(39, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(184, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Количество студентов";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(26, 57);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 100;
            this.dataGridView1.Size = new System.Drawing.Size(716, 291);
            this.dataGridView1.TabIndex = 1;
            this.dataGridView1.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellEndEdit);
            // 
            // rand
            // 
            this.rand.Location = new System.Drawing.Point(43, 354);
            this.rand.Name = "rand";
            this.rand.Size = new System.Drawing.Size(174, 40);
            this.rand.TabIndex = 0;
            this.rand.Text = "Заполнить случайными";
            this.rand.UseVisualStyleBackColor = true;
            this.rand.Click += new System.EventHandler(this.rand_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.studb);
            this.tabPage2.Controls.Add(this.Studg);
            this.tabPage2.Controls.Add(this.studgr);
            this.tabPage2.Controls.Add(this.studbr);
            this.tabPage2.Controls.Add(this.dataGridView2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(768, 400);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // studb
            // 
            this.studb.AutoSize = true;
            this.studb.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.studb.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.studb.Location = new System.Drawing.Point(161, 368);
            this.studb.Name = "studb";
            this.studb.Size = new System.Drawing.Size(333, 18);
            this.studb.TabIndex = 11;
            this.studb.Text = "Студент с наименьшим средним баллом:";
            // 
            // Studg
            // 
            this.Studg.AutoSize = true;
            this.Studg.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Studg.ForeColor = System.Drawing.Color.LimeGreen;
            this.Studg.Location = new System.Drawing.Point(161, 336);
            this.Studg.Name = "Studg";
            this.Studg.Size = new System.Drawing.Size(333, 18);
            this.Studg.TabIndex = 10;
            this.Studg.Text = "Студент с наибольшим средним баллом:";
            // 
            // studgr
            // 
            this.studgr.AutoSize = true;
            this.studgr.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.studgr.ForeColor = System.Drawing.Color.LimeGreen;
            this.studgr.Location = new System.Drawing.Point(496, 336);
            this.studgr.Name = "studgr";
            this.studgr.Size = new System.Drawing.Size(52, 18);
            this.studgr.TabIndex = 9;
            this.studgr.Text = "label9";
            // 
            // studbr
            // 
            this.studbr.AutoSize = true;
            this.studbr.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.studbr.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.studbr.Location = new System.Drawing.Point(495, 368);
            this.studbr.Name = "studbr";
            this.studbr.Size = new System.Drawing.Size(61, 18);
            this.studbr.TabIndex = 8;
            this.studbr.Text = "label10";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column9,
            this.Column10,
            this.Column11,
            this.Column12,
            this.Column14,
            this.Column13});
            this.dataGridView2.Location = new System.Drawing.Point(25, 33);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersWidth = 100;
            this.dataGridView2.Size = new System.Drawing.Size(718, 289);
            this.dataGridView2.TabIndex = 2;
            // 
            // Column9
            // 
            this.Column9.HeaderText = "2";
            this.Column9.Name = "Column9";
            this.Column9.ReadOnly = true;
            this.Column9.Width = 50;
            // 
            // Column10
            // 
            this.Column10.HeaderText = "3";
            this.Column10.Name = "Column10";
            this.Column10.ReadOnly = true;
            this.Column10.Width = 50;
            // 
            // Column11
            // 
            this.Column11.HeaderText = "4";
            this.Column11.Name = "Column11";
            this.Column11.ReadOnly = true;
            this.Column11.Width = 50;
            // 
            // Column12
            // 
            this.Column12.HeaderText = "5";
            this.Column12.Name = "Column12";
            this.Column12.ReadOnly = true;
            this.Column12.Width = 50;
            // 
            // Column14
            // 
            this.Column14.HeaderText = "Н/а";
            this.Column14.Name = "Column14";
            this.Column14.ReadOnly = true;
            // 
            // Column13
            // 
            this.Column13.HeaderText = "Средний балл";
            this.Column13.Name = "Column13";
            this.Column13.ReadOnly = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.lesb);
            this.tabPage3.Controls.Add(this.lesg);
            this.tabPage3.Controls.Add(this.lesgr);
            this.tabPage3.Controls.Add(this.lesbr);
            this.tabPage3.Controls.Add(this.dataGridView3);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(768, 400);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "tabPage3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // lesb
            // 
            this.lesb.AutoSize = true;
            this.lesb.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lesb.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lesb.Location = new System.Drawing.Point(166, 368);
            this.lesb.Name = "lesb";
            this.lesb.Size = new System.Drawing.Size(338, 18);
            this.lesb.TabIndex = 7;
            this.lesb.Text = "Предмет с наименьшим средним баллом:";
            // 
            // lesg
            // 
            this.lesg.AutoSize = true;
            this.lesg.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lesg.ForeColor = System.Drawing.Color.LimeGreen;
            this.lesg.Location = new System.Drawing.Point(166, 336);
            this.lesg.Name = "lesg";
            this.lesg.Size = new System.Drawing.Size(338, 18);
            this.lesg.TabIndex = 6;
            this.lesg.Text = "Предмет с наибольшим средним баллом:";
            // 
            // lesgr
            // 
            this.lesgr.AutoSize = true;
            this.lesgr.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lesgr.ForeColor = System.Drawing.Color.LimeGreen;
            this.lesgr.Location = new System.Drawing.Point(501, 336);
            this.lesgr.Name = "lesgr";
            this.lesgr.Size = new System.Drawing.Size(52, 18);
            this.lesgr.TabIndex = 5;
            this.lesgr.Text = "label4";
            // 
            // lesbr
            // 
            this.lesbr.AutoSize = true;
            this.lesbr.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lesbr.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lesbr.Location = new System.Drawing.Point(500, 368);
            this.lesbr.Name = "lesbr";
            this.lesbr.Size = new System.Drawing.Size(52, 18);
            this.lesbr.TabIndex = 4;
            this.lesbr.Text = "label3";
            // 
            // dataGridView3
            // 
            this.dataGridView3.AllowUserToAddRows = false;
            this.dataGridView3.AllowUserToDeleteRows = false;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column1,
            this.Column6,
            this.Column7,
            this.Column8});
            this.dataGridView3.Location = new System.Drawing.Point(25, 33);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.ReadOnly = true;
            this.dataGridView3.RowHeadersWidth = 100;
            this.dataGridView3.Size = new System.Drawing.Size(718, 289);
            this.dataGridView3.TabIndex = 3;
            // 
            // column2
            // 
            this.column2.FillWeight = 50F;
            this.column2.HeaderText = "2";
            this.column2.Name = "column2";
            this.column2.ReadOnly = true;
            this.column2.Width = 50;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "3";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Width = 50;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "4";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Width = 50;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "5";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            this.Column5.Width = 50;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Н/а";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "Средняя";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            // 
            // Column7
            // 
            this.Column7.HeaderText = "Качество";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            // 
            // Column8
            // 
            this.Column8.HeaderText = "Успеваемость";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.list_les);
            this.tabPage4.Controls.Add(this.list_st);
            this.tabPage4.Controls.Add(this.list);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(768, 400);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "tabPage4";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // list_les
            // 
            this.list_les.BackColor = System.Drawing.Color.Gainsboro;
            this.list_les.Controls.Add(this.label9);
            this.list_les.Controls.Add(this.listst);
            this.list_les.Controls.Add(this.label7);
            this.list_les.Controls.Add(this.comboles);
            this.list_les.Location = new System.Drawing.Point(382, 254);
            this.list_les.Name = "list_les";
            this.list_les.Size = new System.Drawing.Size(380, 140);
            this.list_les.TabIndex = 2;
            this.list_les.TabStop = false;
            this.list_les.Text = "Анализ по предметам";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(189, 7);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(98, 13);
            this.label9.TabIndex = 7;
            this.label9.Text = "Список студентов";
            // 
            // listst
            // 
            this.listst.FormattingEnabled = true;
            this.listst.Location = new System.Drawing.Point(192, 23);
            this.listst.Name = "listst";
            this.listst.Size = new System.Drawing.Size(120, 108);
            this.listst.TabIndex = 6;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 48);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(102, 13);
            this.label7.TabIndex = 5;
            this.label7.Text = "Список предметов";
            // 
            // comboles
            // 
            this.comboles.FormattingEnabled = true;
            this.comboles.Location = new System.Drawing.Point(6, 64);
            this.comboles.Name = "comboles";
            this.comboles.Size = new System.Drawing.Size(121, 21);
            this.comboles.TabIndex = 1;
            this.comboles.SelectedIndexChanged += new System.EventHandler(this.comboles_SelectedIndexChanged);
            // 
            // list_st
            // 
            this.list_st.BackColor = System.Drawing.Color.Gainsboro;
            this.list_st.Controls.Add(this.label8);
            this.list_st.Controls.Add(this.listles);
            this.list_st.Controls.Add(this.label6);
            this.list_st.Controls.Add(this.combost);
            this.list_st.Location = new System.Drawing.Point(7, 254);
            this.list_st.Name = "list_st";
            this.list_st.Size = new System.Drawing.Size(369, 140);
            this.list_st.TabIndex = 1;
            this.list_st.TabStop = false;
            this.list_st.Text = "Анализ по студентам";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(181, 7);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(82, 13);
            this.label8.TabIndex = 6;
            this.label8.Text = "Список долгов";
            // 
            // listles
            // 
            this.listles.FormattingEnabled = true;
            this.listles.Location = new System.Drawing.Point(184, 23);
            this.listles.Name = "listles";
            this.listles.Size = new System.Drawing.Size(120, 108);
            this.listles.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 48);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(98, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "Список студентов";
            // 
            // combost
            // 
            this.combost.FormattingEnabled = true;
            this.combost.Location = new System.Drawing.Point(6, 64);
            this.combost.Name = "combost";
            this.combost.Size = new System.Drawing.Size(121, 21);
            this.combost.TabIndex = 0;
            this.combost.SelectedIndexChanged += new System.EventHandler(this.combost_SelectedIndexChanged);
            // 
            // list
            // 
            this.list.BackColor = System.Drawing.Color.Gainsboro;
            this.list.Controls.Add(this.label5);
            this.list.Controls.Add(this.label4);
            this.list.Controls.Add(this.label3);
            this.list.Controls.Add(this.exit);
            this.list.Controls.Add(this.stipplus);
            this.list.Controls.Add(this.stip);
            this.list.Location = new System.Drawing.Point(7, 7);
            this.list.Name = "list";
            this.list.Size = new System.Drawing.Size(755, 240);
            this.list.TabIndex = 0;
            this.list.TabStop = false;
            this.list.Text = "Списки студентов";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(554, 42);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "Отчислнные";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(286, 41);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(129, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Повышенная стипендия";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(20, 41);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Стипендия";
            // 
            // exit
            // 
            this.exit.FormattingEnabled = true;
            this.exit.Location = new System.Drawing.Point(557, 58);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(173, 160);
            this.exit.TabIndex = 2;
            // 
            // stipplus
            // 
            this.stipplus.FormattingEnabled = true;
            this.stipplus.Location = new System.Drawing.Point(289, 58);
            this.stipplus.Name = "stipplus";
            this.stipplus.Size = new System.Drawing.Size(173, 160);
            this.stipplus.TabIndex = 1;
            // 
            // stip
            // 
            this.stip.FormattingEnabled = true;
            this.stip.Location = new System.Drawing.Point(20, 58);
            this.stip.Name = "stip";
            this.stip.Size = new System.Drawing.Size(173, 160);
            this.stip.TabIndex = 0;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.button4);
            this.tabPage5.Controls.Add(this.button1);
            this.tabPage5.Controls.Add(this.lesr);
            this.tabPage5.Controls.Add(this.chartkolvo);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(768, 400);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "tabPage5";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(475, 340);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(225, 54);
            this.button4.TabIndex = 3;
            this.button4.Text = "Сохранить график";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(63, 340);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(225, 54);
            this.button1.TabIndex = 2;
            this.button1.Text = "Сохранить график";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lesr
            // 
            chartArea3.Area3DStyle.Enable3D = true;
            chartArea3.Area3DStyle.IsClustered = true;
            chartArea3.Name = "ChartArea1";
            this.lesr.ChartAreas.Add(chartArea3);
            legend3.Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Top;
            legend3.LegendStyle = System.Windows.Forms.DataVisualization.Charting.LegendStyle.Column;
            legend3.Name = "Legend1";
            this.lesr.Legends.Add(legend3);
            this.lesr.Location = new System.Drawing.Point(352, 33);
            this.lesr.Name = "lesr";
            series4.ChartArea = "ChartArea1";
            series4.LabelBorderDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Dot;
            series4.Legend = "Legend1";
            series4.MarkerSize = 3;
            series4.Name = "Успеваемость";
            series5.ChartArea = "ChartArea1";
            series5.Legend = "Legend1";
            series5.Name = "Качество";
            series5.YValuesPerPoint = 2;
            this.lesr.Series.Add(series4);
            this.lesr.Series.Add(series5);
            this.lesr.Size = new System.Drawing.Size(410, 301);
            this.lesr.TabIndex = 1;
            this.lesr.Text = "chart1";
            title3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            title3.Name = "Title1";
            title3.Text = "Предметы";
            this.lesr.Titles.Add(title3);
            // 
            // chartkolvo
            // 
            chartArea4.Area3DStyle.Enable3D = true;
            chartArea4.Name = "ChartArea1";
            this.chartkolvo.ChartAreas.Add(chartArea4);
            this.chartkolvo.DataSource = this.chartkolvo.ChartAreas;
            legend4.Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Top;
            legend4.Name = "Legend1";
            legend4.TitleFont = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.chartkolvo.Legends.Add(legend4);
            this.chartkolvo.Location = new System.Drawing.Point(6, 33);
            this.chartkolvo.Name = "chartkolvo";
            series6.BorderWidth = 5;
            series6.ChartArea = "ChartArea1";
            series6.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Doughnut;
            series6.Legend = "Legend1";
            series6.Name = "Series1";
            this.chartkolvo.Series.Add(series6);
            this.chartkolvo.Size = new System.Drawing.Size(320, 301);
            this.chartkolvo.TabIndex = 0;
            this.chartkolvo.Text = "chart1";
            title4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            title4.Name = "Title1";
            title4.Text = "Количество каждого вида оценок";
            this.chartkolvo.Titles.Add(title4);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lessons)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stud)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.list_les.ResumeLayout(false);
            this.list_les.PerformLayout();
            this.list_st.ResumeLayout(false);
            this.list_st.PerformLayout();
            this.list.ResumeLayout(false);
            this.list.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.lesr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartkolvo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button rand;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.NumericUpDown lessons;
        private System.Windows.Forms.NumericUpDown stud;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button voyti;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button read;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.Label lesbr;
        private System.Windows.Forms.Label lesgr;
        private System.Windows.Forms.Label lesb;
        private System.Windows.Forms.Label lesg;
        private System.Windows.Forms.Label studb;
        private System.Windows.Forms.Label Studg;
        private System.Windows.Forms.Label studgr;
        private System.Windows.Forms.Label studbr;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column14;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartkolvo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataVisualization.Charting.Chart lesr;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox list_les;
        private System.Windows.Forms.GroupBox list_st;
        private System.Windows.Forms.GroupBox list;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox exit;
        private System.Windows.Forms.ListBox stipplus;
        private System.Windows.Forms.ListBox stip;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ListBox listst;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox comboles;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ListBox listles;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox combost;
    }
}

