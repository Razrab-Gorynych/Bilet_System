﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Bookmarks
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int st, les, mak;
        string s = "";

        private void rand_Click(object sender, EventArgs e)// автоматическое заполнение таблицы
        {
            if (stud.Value != 0 || lessons.Value != 0)
            {
                st = Convert.ToInt32(stud.Value);
                les = Convert.ToInt32(lessons.Value);
                dataGridView1.RowCount = st;
                dataGridView1.ColumnCount = les;
                Random rand = new Random();

                for (int x = 0; x < st; x++)
                {
                    for (int y = 0; y < les; y++)
                    {
                        dataGridView1.Rows[x].Cells[y].Style.BackColor = Color.White; 
                    }
                }

                for (int x = 0; x < st; x++)         //заполнение массива
                {
                    for (int y = 0; y < les; y++)
                    {

                        mak = rand.Next(0, 13);
                        switch (mak)
                        {
                            case 0: s = "2"; break;
                            case 1: s = "3"; break;
                            case 2: s = "4"; break;
                            case 3: s = "5"; break;
                            case 4: s = "Н/а"; break;
                            case 5: s = "4"; break;
                            case 6: s = "3"; break;
                            case 7: s = "4"; break;
                            case 8: s = "3"; break;
                            case 9: s = "5"; break;
                            case 10: s = "3"; break;
                            case 11: s = "4"; break;
                            case 12: s = "5"; break;
                        }

                        dataGridView1.Rows[x].Cells[y].Value = s;

                        if (s == "2" || s == "Н/а")
                        {
                            for (int a = 0; a < les; a++)
                                dataGridView1.Rows[x].Cells[a].Style.BackColor = Color.Red;     //красная строка, если есть оценка 2 или Н/а
                        }
                    }
                }
            }

            else
            {
                MessageBox.Show("Выберите кол-во студентов и предметов");
            }
        }

        private void Form1_Load(object sender, EventArgs e) // наименование вкладок
        {
            tabPage1.Text = "Сводная ведомость";
            tabPage2.Text = "Статистика по студентам";
            tabPage3.Text = "Статистика по предметам";
            tabPage4.Text = "Результаты";
            tabPage5.Text = "Диаграммы анализа";
        }

        private void stud_ValueChanged(object sender, EventArgs e) // добавление вкладки "студенты"
        {
            if (stud.Value != 0)
            {
                dataGridView1.RowCount = (int)stud.Value;
                dataGridView2.RowCount = (int)stud.Value;

                for (int y = 0; y < dataGridView1.Rows.Count; y++)
                    dataGridView1.Rows[y].HeaderCell.Value = $"Студент {y + 1}";

                dataGridView2.RowCount = (int)stud.Value + 1;

                for (int y = 0; y < dataGridView1.Rows.Count; y++)
                    dataGridView2.Rows[y].HeaderCell.Value = $"Студент {y + 1}";

                read.Enabled = false;

                dataGridView2.Rows[(int)stud.Value].HeaderCell.Value = $"Итого:";
            }
        } 

        private void lessons_ValueChanged(object sender, EventArgs e) // добавление вкладки "предметы"
        {
            
            if (lessons.Value != 0)
            {
                dataGridView1.ColumnCount = (int)lessons.Value;

                for (int y = 0; y > les; y++)
                {
                    dataGridView1.Columns[y].HeaderCell.Value = "";
                }

                for (int j = 0; j < dataGridView1.Columns.Count; j++)
                {
                    dataGridView1.Columns[j].HeaderCell.Value = $"Предмет {j + 1}";
                }

                read.Enabled = false;

                dataGridView3.RowCount = (int)lessons.Value + 1;

                for (int x = 0; x < (int)lessons.Value; x++)
                {
                    dataGridView3.Rows[x].HeaderCell.Value = $"Предмет {x + 1}";
                }

                dataGridView3.Rows[(int)lessons.Value].HeaderCell.Value = $"Итого:";
            }
        }

        private void read_Click(object sender, EventArgs e) //заполнение из txt-файла
        {
            StreamReader read = new StreamReader("studs.txt");
            DataSet set = new DataSet();
            set.Tables.Add();
            string a = read.ReadLine();
            string[] b = System.Text.RegularExpressions.Regex.Split(a, ",");

            for (int x =0; x < b.Length; x++)
            {
                set.Tables[0].Columns.Add(b[x]);
            }

            string column = read.ReadLine();

            while (column!=null)
            {
                String[] r = System.Text.RegularExpressions.Regex.Split(column, ",");
                set.Tables[0].Rows.Add(r);
                column = read.ReadLine();

            }
            dataGridView1.DataSource = set.Tables[0];

            stud.Enabled = false;
            lessons.Enabled = false;
        }

        private void tabControl1_Deselecting(object sender, TabControlCancelEventArgs e) // проверка на заполненность таблицы, проверка пароля, и заполнение таблиц "статистика предметов" и "статистика студентов"
        {

            //СВОДНАЯ ВЕДОМОСТЬ...................................................................................................................................

            if (e.TabPage.Text == tabPage1.Text)   //контроль перехода на вторую вкладку
            {
                if (textBox1.Text != "123")
                {
                    e.Cancel = true;
                    groupBox1.Visible = true;
                }

                else
                {
                    groupBox1.Visible = false;
                    textBox1.Text = "";
                    st = Convert.ToInt32(stud.Value);
                    dataGridView1.RowCount = st;
                }
            }

            else
            {
                if (e.TabPage.Text == tabPage1.Text)
                {

                    if (textBox1.Text != "123")
                    {
                        e.Cancel = true;
                        groupBox1.Visible = true;
                    }

                    else
                    {
                        groupBox1.Visible = false;
                        textBox1.Text = "";
                    }
                }
            }



            if (stud.Value != 0 || lessons.Value != 0)    //проверка на заполненность таблицы для перехода на другую вкладку
            {
                st = Convert.ToInt32(stud.Value);
                les = Convert.ToInt32(lessons.Value);
                dataGridView1.RowCount = st;
                dataGridView1.ColumnCount = les;

                for (int x = 0; x < st; x++)   
                {
                    for (int y = 0; y < les; y++)
                    {
                        s = Convert.ToString(this.dataGridView1.Rows[x].Cells[y].Value);

                        if (s != "2" && s != "3" && s != "4" && s != "5" && s != "Н/а")
                        {
                            MessageBox.Show("Таблица заполнена не полностью!");
                            e.Cancel = true;
                            return;
                        }
                    }
                }  
            }

            //СТАТИСТИКА СТУДЕНТОВ........................................................................................................................................................................

            int kol2, kol3, kol4, kol5, n, m, na, itog = 0, itog2 = 0;
            double sred = 0, sred2 = 0;

            n = (int)stud.Value;
            m = (int)lessons.Value;

            dataGridView2.Columns[5].DefaultCellStyle.Format = "0.00";

            for (int i = 0; i < n; i++)     //рассчёт кол-ва оценок и среднего балла
            {
                kol2 = kol3 = kol4 = kol5 = na = 0;

                for (int j = 0; j < m; j++)
                {
                    switch (dataGridView1[j, i].Value)
                    {
                        case "2": kol2++; break;
                        case "3": kol3++; break;
                        case "4": kol4++; break;
                        case "5": kol5++; break;
                        case "Н/а": na++; break;
                    }
                }

                dataGridView2[0, i].Value = kol2;
                dataGridView2[1, i].Value = kol3;
                dataGridView2[2, i].Value = kol4;
                dataGridView2[3, i].Value = kol5;

                sred = (2 * kol2 + 3 * kol3 + 4 * kol4 + 5 * kol5) / (double)m;
                dataGridView2[5, i].Value = sred;

                dataGridView2[4, i].Value = na;
            }



            for (int y = 0; y < 5; y++)     //кол-во оценок
            {
                for (int x = 0; x < n; x++)
                {
                    itog += (int)dataGridView2[y, x].Value;
                }

                dataGridView2[y, n].Value = itog;
                itog = 0;
            }



            sred = 0;

            for (int x = 0; x < n; x++)     //средний балл всех студентов
            {
                sred += (double)dataGridView2[5, x].Value;
            }

            dataGridView2[5, n].Value = sred / (double)n;



            double min1 = 6, max1 = 0;
            int min2 = 0, max2 = 0;

            for (int x = 0; x < n; x++)    //поиск лучшего и худшего студентов
            {
                if ((double)dataGridView2[5, x].Value > max1)
                {
                    max1 = (double)dataGridView2[5, x].Value;
                    max2 = x;
                }
                if ((double)dataGridView2[5, x].Value < min1)
                {
                    min1 = (double)dataGridView2[5, x].Value;
                    min2 = x;
                }
            }

            studbr.Text = Convert.ToString(dataGridView2.Rows[min2].HeaderCell.Value);

            studgr.Text = Convert.ToString(dataGridView2.Rows[max2].HeaderCell.Value);







                //СТАТИСТИКА ПРЕДМЕТОВ...........................................................................................................................................................................


                dataGridView3.Columns[5].DefaultCellStyle.Format = "0.00";

            for (int y = 0; y < m; y++)     //рассчёт кол-ва оценок и среднего балла
            {
                kol2 = kol3 = kol4 = kol5 = na = 0;

                for (int x = 0; x < n; x++)
                {
                    switch (dataGridView1[y, x].Value)
                    {
                        case "2": kol2++; break;
                        case "3": kol3++; break;
                        case "4": kol4++; break;
                        case "5": kol5++; break;
                        case "Н/а": na++; break;
                    }
                }

                dataGridView3[0, y].Value = kol2;
                dataGridView3[1, y].Value = kol3;
                dataGridView3[2, y].Value = kol4;
                dataGridView3[3, y].Value = kol5;
                sred = (2 * kol2 + 3 * kol3 + 4 * kol4 + 5 * kol5) / (double)n;
                dataGridView3[5, y].Value = sred;
                dataGridView3[4, y].Value = na;              
            }



            for (int y = 0; y < 5; y++)        //кол-во оценок
            {
                for (int x = 0; x < m; x++)
                {
                    itog2 += (int)dataGridView3[y, x].Value;
                }

                dataGridView3.Rows[m].Cells[y].Value = itog2;
                itog2 = 0;
            }



            sred2 = 0;

            for (int x = 0; x < m; x++)       //средний балл всех студентов
            {
                sred2 += (double)dataGridView3[5, x].Value;
            }

            dataGridView3[5, m].Value = sred2 / (double)m;



            min1 = 6;  max1 = 0;
            min2 = 0;  max2 = 0;

            for (int x = 0; x < m; x++)                   //поиск лучшего и худшего предметов по оценкам студентов
            {
                if ((double)dataGridView3[5, x].Value > max1)
                {
                    max1 = (double)dataGridView3.Rows[x].Cells[5].Value;
                    max2 = x;
                }
                if ((double)dataGridView3[5, x].Value < min1)
                {
                    min1 = (double)dataGridView3.Rows[x].Cells[5].Value;
                    min2 = x;
                }
            }

            lesbr.Text = Convert.ToString(dataGridView3.Rows[min2].HeaderCell.Value);

            lesgr.Text = Convert.ToString(dataGridView3.Rows[max2].HeaderCell.Value);


            double progress = 0, kachestvo = 0;


            for (int j = 0; j < m; j++)                //заполнение столбцов "качество" и "успеваемость"
            {
                for (int i = 0; i < n; i++)
                {
                    switch (Convert.ToString(dataGridView1[j, i].Value))
                    {
                        case "4": case "5": progress++; kachestvo++; break;
                        case "3": progress++; break;
                    }
                }

                dataGridView3[6, j].Value = String.Format($"{kachestvo / n:p0}");

                dataGridView3[7, j].Value = String.Format($"{progress / n:p0}");
                    
                this.lesr.Series[1].Points.AddXY(j + 1, (kachestvo / n) * 100);   // Заполнение диаграммы "предмет"

                this.lesr.Series[0].Points.AddXY(j + 1, (progress / n) * 100);

                progress = kachestvo = 0;
            }

            //ДИАГРАММЫ.............................................................................................................................................................................................


            chartkolvo.Series[0].Points.Clear();
            chartkolvo.Series[0].IsValueShownAsLabel = true;   //заполнение диаграммы "Количество каждого вида оценок"

            int a;

            for (int x = 0; x < 5; x++)
            {
                a = (int)dataGridView3[x, m].Value;
                chartkolvo.Series[0].Points.AddY(a);
            }
            this.chartkolvo.Series[0].Points[0].LegendText = "2";
            this.chartkolvo.Series[0].Points[1].LegendText = "3";
            this.chartkolvo.Series[0].Points[2].LegendText = "4";
            this.chartkolvo.Series[0].Points[3].LegendText = "5";
            this.chartkolvo.Series[0].Points[4].LegendText = "Н/а";


            //РЕЗУЛЬТАТЫ.............................................................................................................................................................................................
            stip.Items.Clear();
            stipplus.Items.Clear();
            exit.Items.Clear();
            listles.Items.Clear();
            listst.Items.Clear();
            comboles.Items.Clear();
            combost.Items.Clear();

            for (int x = 0; x < n; x++)     //список студентов со стипендией, с повышенной стипендией и отчисленные
            {        
                if (Convert.ToInt32(dataGridView2[0, x].Value) + Convert.ToInt32(dataGridView2[4, x].Value) >= 3)
                {   
                    exit.Items.Add($"{dataGridView2.Rows[x].HeaderCell.Value}");
                }

                if (Convert.ToInt32(dataGridView2[0, x].Value) == 0 && Convert.ToInt32(dataGridView2[1, x].Value) == 0 && Convert.ToInt32(dataGridView2[2, x].Value) > 0 && Convert.ToInt32(dataGridView2[3, x].Value) > 0 && Convert.ToInt32(dataGridView2[4, x].Value) == 0)
                {
                    stip.Items.Add($"{dataGridView2.Rows[x].HeaderCell.Value}");
                }             

                if (Convert.ToInt32(dataGridView2[0, x].Value) == 0 && Convert.ToInt32(dataGridView2[1, x].Value) == 0 && Convert.ToInt32(dataGridView2[2, x].Value) == 0 && Convert.ToInt32(dataGridView2[3, x].Value) > 0 && Convert.ToInt32(dataGridView2[4, x].Value) == 0)
                {
                    stipplus.Items.Add($"{dataGridView2.Rows[x].HeaderCell.Value}");
                }
            }

            for (int x = 0; x < m; x++)                                      //добавление студентов и предметов в combo
            {
                comboles.Items.Add(dataGridView3.Rows[x].HeaderCell.Value);
            }

            for (int x = 0; x < n; x++)
            {
                combost.Items.Add($"{dataGridView2.Rows[x].HeaderCell.Value}");
            }
        }
      

        private void button3_Click_1(object sender, EventArgs e)
        {
            groupBox1.Visible = false;
            textBox1.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog sfd = new SaveFileDialog())                         //сохранение диаграммы "количество оценок"
            {
                sfd.Title = "Сохранить изображение как ...";
                sfd.Filter = "*.PNG|*.PNG";
                sfd.AddExtension = true;
                sfd.FileName = "Количество оценок";
                if (sfd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    chartkolvo.SaveImage(sfd.FileName, System.Windows.Forms.DataVisualization.Charting.ChartImageFormat.Png);
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog sfd = new SaveFileDialog())                         //сохранение графика "предметы"
            {
                sfd.Title = "Сохранить изображение как ...";
                sfd.Filter = "*.PNG|*.PNG";
                sfd.AddExtension = true;
                sfd.FileName = "Предметы";
                if (sfd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    lesr.SaveImage(sfd.FileName, System.Windows.Forms.DataVisualization.Charting.ChartImageFormat.Png);
                }
            }
        }

        private void combost_SelectedIndexChanged(object sender, EventArgs e) //Анализ по студентам
        {
            int ind = combost.Items.IndexOf(combost.SelectedItem.ToString());             
            listles.Items.Clear();

            for (int x = 0; x < (int)lessons.Value; x++)
            {


                if ((string)dataGridView1[x, ind].Value == "2" || (string)dataGridView1[x, ind].Value == "Н/а")
                {
                    listles.Items.Add(dataGridView1.Columns[x].HeaderCell.Value);
                }

            }
        }

        private void comboles_SelectedIndexChanged(object sender, EventArgs e) //анализ по предметам
        {
            int ind = comboles.Items.IndexOf(comboles.SelectedItem.ToString());
            listst.Items.Clear();

            for (int x = 0; x < (int)stud.Value; x++)
            {
                if ((string)dataGridView1[ind, x].Value == "2" || (string)dataGridView1[ind, x].Value == "Н/а")
                {
                    listst.Items.Add(dataGridView1.Rows[x].HeaderCell.Value);
                }
            }
        }

        private void voyti_Click(object sender, EventArgs e)   // кнопка подвертждения пароля
        {
            if (textBox1.Text != "123")
                MessageBox.Show("Не правильный пароль");

            else
                groupBox1.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e) // кнопка отмены при окне с паролем
        {
            groupBox1.Visible = false;
            textBox1.Text = "";
        }

        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e) // проверка заполнения таблицы
        {
            if (stud.Value != 0 || lessons.Value != 0)
            {
                s = Convert.ToString(this.dataGridView1[e.ColumnIndex, e.RowIndex].Value);

                if (s != "2" && s != "3" && s != "4" && s != "5" && s != "Н/а")
                {
                    this.dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = "";
                    MessageBox.Show("Допустимые значения: 2, 3, 4, 5, Н/а");
                }
            }  
        }
    }
}

